========================================
 Hide admin from user and partner lists
========================================

TODO
