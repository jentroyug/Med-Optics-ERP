Updates
=======

`1.0.1`
-------

- FIX: hide admin in channel chat

`1.0.0`
-------

- init version
