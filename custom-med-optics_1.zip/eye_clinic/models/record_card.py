# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import Warning as UserError
from odoo.exceptions import ValidationError
from datetime import datetime

class record_card(models.Model):
    _name = 'eye_clinic.record_card'
    _inherit = ['mail.thread', 'ir.needaction_mixin']

    recordcard_id = fields.Char(string="Record Card No.", readonly=True)
    date = fields.Date(string="Date", default=fields.Date.today)
    patient_id = fields.Many2one('eye_clinic.patient', string='Patient', required=True)
    branch_id = fields.Many2one('eye_clinic.branches', string='Branch', readonly=True, compute="_compute_branch", store=True)
    physician_type = fields.Many2one('eye_clinic.physician_speciality', string='Physician Type', required=True)
    physician_id = fields.Many2one('eye_clinic.physicians', string='Physician', required=True, domain="[('speciality_id', '=', physician_type)]")
    payment_type = fields.Selection([
        ('Cash', "Cash"),
        ('Mobile Money', "Mobile Money"),
        ('Credit Debit Card', "Credit Debit Card"),
        ('Insurance', "Insurance"),
    ], string="Payment Type", required=True)
    mm_phone_number = fields.Char(string="Mobile Phone Number.")  
    credit_card_number = fields.Char(string="Credit Card Number.")
    insurance_id = fields.Many2one('eye_clinic.insurance_companies', string='Insurance Company')   
    policy_id = fields.Many2one('eye_clinic.insurance_policies', string='Insurance Scheme')  
    salesorder_id = fields.Many2one('sale.order', string="Sales Order No.", readonly=True)
    invoice_id = fields.Many2one('account.invoice', string="Invoice No.", readonly=True)

    # Page 1 – Symptoms, History, General Health, Medication
    reason_visit = fields.Text(string="Reason for Visit", required=True)
    history_refractive = fields.Text(string="Person Ocular History (Refractive)")
    history_health = fields.Text(string="Person Ocular History (Health)")
    history_past_present = fields.Text(string="Personal Genera Health History (Past and Present)")
    ocular_symptoms = fields.Text(string="Ocular Symptoms")
    date_last_eye_exam = fields.Date(string='Date of Last Eye Examination') 
    where_last_eye_exam = fields.Char(string="Where was Last Eye Examination performed?")
    date_last_medical_exam = fields.Date(string='Date of Last Eye Examination') 
    where_last_medical_exam = fields.Char(string="Where was Last Medical Examination performed?")
    familty_ocular_history = fields.Text(string="Family Ocular history")
    general_family_history = fields.Text(string="General Family History (Past and Present)")
    medical_dosage = fields.Text(string="Medical, dosage, frequency, condition")
    allergies = fields.Text(string="Allergies (Medicine, General)")

    #VA
    negativeRX_dist_OD = fields.Char(string="Distance OD")
    negativeRX_dist_OS = fields.Char(string="Distance OS")
    negativeRX_dist_OU = fields.Char(string="Distance OU")
    negativeRX_near_OD = fields.Char(string="Near OD")
    negativeRX_near_OS = fields.Char(string="Near OS")
    negativeRX_near_OU = fields.Char(string="Near OU")

    positiveRX_dist_OD = fields.Char(string="Distance OD")
    positiveRX_dist_OS = fields.Char(string="Distance OS")
    positiveRX_dist_OU = fields.Char(string="Distance OU")
    positiveRX_near_OD = fields.Char(string="Near OD")
    positiveRX_near_OS = fields.Char(string="Near OS")
    positiveRX_near_OU = fields.Char(string="Near OU")

    PH_dist_OD = fields.Char(string="Distance OD")
    PH_dist_OS = fields.Char(string="Distance OS")

    positiveRXCL_dist_OD = fields.Char(string="Distance OD")
    positiveRXCL_dist_OS = fields.Char(string="Distance OS")
    positiveRXCL_dist_OU = fields.Char(string="Distance OU")
    positiveRXCL_near_OD = fields.Char(string="Near OD")
    positiveRXCL_near_OS = fields.Char(string="Near OS")
    positiveRXCL_near_OU = fields.Char(string="Near OU")

    cl_status = fields.Text(string="CL Status (SLE)")

    AA_OD = fields.Char(string="AA OD")
    AA_OS = fields.Char(string="AA OS")
    AA_OU = fields.Char(string="AA OU")

    colourvision_OD = fields.Char(string="Colour Vision OD")
    colourvision_OS = fields.Char(string="Colour Vision OS")
    colourvision_test = fields.Char(string="Colour Vision Test")

    stereopsis = fields.Char(string='Stereopsis "')
    stereopsis_test = fields.Char(string="Stereopsis Test")

    npc = fields.Char(string="NPC (cm)")
    npc_selection = fields.Selection([
        ('Obj Subj', "Obj Subj"),
        ('OD OS', "OD OS"),
    ], string="Obj Subj / OD OS") 

    versions = fields.Char(string="Versions")
    pd = fields.Char(string="PD (mm) (D/N)")

    CT_D = fields.Char(string="(D) cc / sc")
    CT_N = fields.Char(string="(N) cc / sc")

    CT_D = fields.Char(string="(D) cc / sc")
    CT_N = fields.Char(string="(N) cc / sc")

    CF_OD = fields.Char(string="CF OD")
    CF_OS = fields.Char(string="CF OS")

    pupils_E = fields.Char(string="Pupils E")
    pupils_R = fields.Char(string="Pupils R")
    pupils_R2 = fields.Char(string="Pupils R")
    pupils_mg = fields.Char(string="Pupils MG")

    pupil_Dia_m_dimbright = fields.Char(string="Pupil Dia M Dim/Bright")
    pupil_Dia_m_time = fields.Char(string="Pupil Dia M Time")

    keratometry_OD = fields.Char(string="Keratometry OD - X  @  D ")
    keratometry_OD_mires = fields.Char(string="Keratometry OD Mires")
    keratometry_OS = fields.Char(string="Keratometry OS - X  @  D ")
    keratometry_OS_mires = fields.Char(string="Keratometry OS Mires")

    objective_OD = fields.Char(string="Objective OD")
    objective_OD_VA = fields.Char(string="Objective OD VA")
    objective_OS = fields.Char(string="Objective OS")
    objective_OS_VA = fields.Char(string="Objective OS VA")

    subjective_OD = fields.Char(string="Subjective OD")
    subjective_OD_VA = fields.Char(string="Subjective OD VA")
    subjective_OS = fields.Char(string="Subjective OS")
    subjective_OS_VA = fields.Char(string="Subjective OS VA")
    phoropter_trialframe_ODS = fields.Char(string="Phoropter Trial frame ODS")

    near_tentativeadd_OD = fields.Char(string="Tentative Add OD")
    near_tentativeadd_OS = fields.Char(string="Tentative Add OS")
    near_tentativeadd_NRA = fields.Char(string="Tentative Add NRA")
    near_tentativeadd_PRA = fields.Char(string="Tentative Add PRA")
    near_tentativeadd_balanceadd = fields.Char(string="Tentative Balance Add")

    distance_phorias_h = fields.Char(string="Distance Phorias (H)")
    distance_vergences_hbi = fields.Char(string="Distance Vergences (H) BI")
    distance_vergences_hbo = fields.Char(string="Distance Vergences (H) BO - Maddox / VG")
    distance_phorias_v = fields.Char(string="Distance Phorias (V)")
    distance_vergences_vbuod = fields.Char(string="Distance Vergences (V) BU OD")
    distance_vergences_vbdod = fields.Char(string="Distance Vergences (V) BD OD - Maddox / VG")

    near_phorias_h = fields.Char(string="Near Phorias (H)")
    near_vergences_hbi = fields.Char(string="Near Vergences (H) BI")
    near_vergences_hbo = fields.Char(string="Near Vergences (H) BO - Maddox / VG")
    near_phorias_v = fields.Char(string="Near Phorias (V)")
    near_vergences_vbuod = fields.Char(string="Near Vergences (V) BU OD")
    near_vergences_vbdod = fields.Char(string="Near Vergences (V) BD OD - Maddox / VG")

    ODmm  = fields.Char(string="OD mm@")
    OSmm  = fields.Char(string="OS mm@")

    complimentary_tests = fields.Text(string="Complimentary Tests")

    #Trial Final RX
    asper_subjective_rx = fields.Boolean(string="As per Subjective RX")

    trialfinal_OD  = fields.Char(string="Trial Final OD")
    trialfinal_OS  = fields.Char(string="Trial Final OS")
    trialfinal_OD_VA  = fields.Char(string="Trial Final OD VA")
    trialfinal_OS_VA  = fields.Char(string="Trial Final OS VA")
    trialfinal_OD_VA_ADD  = fields.Char(string="Trial Final OD VA ADD D")
    trialfinal_OS_VA_ADD  = fields.Char(string="Trial Final OS VA ADD D")
    trialfinal_OD_VA_ADD_VA  = fields.Char(string="Trial Final OD VA ADD VA")
    trialfinal_OS_VA_ADD_VA  = fields.Char(string="Trial Final OS VA ADD VA")
    trialfinal_WD  = fields.Char(string="Trial Final OD WD (cm)")
    trialfinal_range  = fields.Char(string="Trial Final Range, From-To (cm)")

    #Slit Lamp Examination
    OD_eyelids = fields.Char(string="Eyelids")
    OD_conjuctiva = fields.Char(string="Conjuctiva")
    OD_cornea = fields.Char(string="Cornea")
    OD_tearfilm = fields.Char(string="Tear film")
    OD_iris = fields.Char(string="Iris")
    OD_lens = fields.Char(string="Lens")
    OD_anteriorchamber= fields.Char(string="Anterior Chamber")
    OD_ACAngel_T = fields.Char(string="AC Angle(VH) T")
    OD_ACAngel_N = fields.Char(string="AC Angle(VH) N")
    OD_ACAngel_photo = fields.Binary(string='AC Angle(VH) Photo')

    OS_eyelids = fields.Char(string="Eyelids")
    OS_conjuctiva = fields.Char(string="Conjuctiva")
    OS_cornea = fields.Char(string="Cornea")
    OS_tearfilm = fields.Char(string="Tear film")
    OS_iris = fields.Char(string="Iris")
    OS_lens = fields.Char(string="Lens")
    OS_anteriorchamber= fields.Char(string="Anterior Chamber")
    OS_ACAngel_T = fields.Char(string="Angle(VH) T")
    OS_ACAngel_N = fields.Char(string="AC Angle(VH) N")
    OS_ACAngel_photo = fields.Binary(string='AC Angle(VH) Photo')

    #T
    T_OD = fields.Char(string="T OD")
    T_OD_mmHg = fields.Char(string="T OD mmHg")
    GM_OS = fields.Char(string="GM OS")
    GM_OS_mmHg = fields.Char(string="GM OS mmHg")
    PK = fields.Char(string="PK")
    PK_gtts = fields.Char(string="PK gtts")
    PK_gtts_at = fields.Char(string="PK gtts @ _ : _")
    NCT = fields.Boolean(string="Told Patient not to rub eyes to the next 30 minutes")

    #Funduscopy
    DO = fields.Boolean(string="DO")
    MIO = fields.Boolean(string="MIO")
    BIO = fields.Boolean(string="BIO")
    VOLK = fields.Boolean(string="VOLK")
    funduscopy_photo = fields.Boolean(string="Photo")
    funduscopy_photo_attach = fields.Binary(string='Attach Photo')
    Undialated = fields.Boolean(string="Undialated")
    Dialated = fields.Boolean(string="Dialated")
    Dialated_with = fields.Selection([
        ('Option1', "Option1"),
        ('Option1', "Option1"),
    ], string="Dialated with") 
    Dialated_with_gtts1 = fields.Char(string="Dialated with gtts")
    Dialated_with_percent1 = fields.Char(string="Dialated with Percent %")
    Dialated_with_at1 = fields.Char(string="Dialated with @")
    Dialated_with_gtts2 = fields.Char(string="Dialated with gtts")
    Dialated_with_percent2 = fields.Char(string="Dialated with Percent %")
    Dialated_with_at2 = fields.Char(string="Dialated with @")
    patient_sideeffects_meds = fields.Boolean(string="Patient informed of the side effects of the Medication.")

    lefteye_cupdisk = fields.Char(string="Cup/Disk (H/V)")
    lefteye_neuro_retinal_rim = fields.Char(string="Neuro Retinal Rim")
    lefteye_isntrule= fields.Char(string="ISNT Rule")
    lefteye_avcrossings = fields.Char(string="AV Crossings")
    lefteye_venouspulse = fields.Char(string="Venous Pulse")
    lefteye_laminacribrosa = fields.Char(string="Lamina Cribrosa")
    lefteye_bloodvessels_HR = fields.Char(string="Blood Vessels HR")
    lefteye_bloodvessels_AS = fields.Char(string="Blood Vessels AS")
    lefteye_macula= fields.Char(string="Macula")
    lefteye_fovealreflex= fields.Char(string="Foveal Reflex")
    lefteye_vitreous = fields.Char(string="Vitreous")
    lefteye_periphery = fields.Char(string="Periphery")

    righteye_cupdisk = fields.Char(string="Cup/Disk (H/V)")
    righteye_neuro_retinal_rim = fields.Char(string="Neuro Retinal Rim")
    righteye_isntrule= fields.Char(string="ISNT Rule")
    righteye_avcrossings = fields.Char(string="AV Crossings")
    righteye_venouspulse = fields.Char(string="Venous Pulse")
    righteye_laminacribrosa = fields.Char(string="Lamina Cribrosa")
    righteye_bloodvessels_HR = fields.Char(string="Blood Vessels HR")
    righteye_bloodvessels_AS = fields.Char(string="Blood Vessels AS")
    righteye_macula= fields.Char(string="Macula")
    righteye_fovealreflex= fields.Char(string="Foveal Reflex")
    righteye_vitreous = fields.Char(string="Vitreous")
    righteye_periphery = fields.Char(string="Periphery")

    #Final RX
    finalRX_OD = fields.Char(string="Final RX OD")
    finalRX_OS = fields.Char(string="Final RX OS")
    finalRX_Add_OD = fields.Char(string="Add OD")
    finalRX_Add_OS = fields.Char(string="Add OS")
    finalRX_Type_OD = fields.Char(string="Type OD")
    finalRX_Type_OS = fields.Char(string="Type OS")
    finalRX_PD_OD = fields.Char(string="PD (D/N) OD - mm")
    finalRX_PD_OS = fields.Char(string="PD (D/N) OS - mm")
    finalRX_Prism_OD = fields.Char(string="Prism OD")
    finalRX_Prism_OS = fields.Char(string="Prism OS")
    finalRX_Material_OD = fields.Char(string="Material OD")
    finalRX_Material_OS = fields.Char(string="Material OS")
    finalRX_Seg_OD = fields.Char(string="Seg. Ht OD - mm")
    finalRX_Seg_OS = fields.Char(string="Seg. Ht OS - mm")
    finalRX_BC_OD = fields.Char(string="B.C OD - D")
    finalRX_BC_OS = fields.Char(string="B.C OS - D")
    finalRX_TintAR_OD = fields.Char(string="Tint/AR OD")
    finalRX_TintAR_OS = fields.Char(string="Tint/AR OS")

    finalRX_RX_for = fields.Char(string="RX for")
    finalRX_fulltime = fields.Char(string="Full time")
    finalRX_distance = fields.Char(string="Distance")
    finalRX_near = fields.Char(string="Near")
    finalRX_PRN = fields.Char(string="PRN")

    final_eye_defect = fields.Selection([
        ('Myopia', "Myopia"),
        ('Hyperopia', "Hyperopia"),
        ('Astignatism', "Astignatism"),
        ('Presbyopia', "Presbyopia"),
    ], string="Eye Defect", required=True) 

    #Table for Final RX
    tble_finalRX_OD = fields.Char(string="Final RX OD")
    tble_finalRX_OS = fields.Char(string="Final RX OS")
    tble_finalRX_Add_OD = fields.Char(string="Add OD")
    tble_finalRX_Add_OS = fields.Char(string="Add OS")
    tble_finalRX_Type_OD = fields.Char(string="Type OD")
    tble_finalRX_Type_OS = fields.Char(string="Type OS")
    tble_finalRX_PD_OD = fields.Char(string="PD (D/N) OD - mm")
    tble_finalRX_PD_OS = fields.Char(string="PD (D/N) OS - mm")
    tble_finalRX_Prism_OD = fields.Char(string="Prism OD")
    tble_finalRX_Prism_OS = fields.Char(string="Prism OS")
    tble_finalRX_Material_OD = fields.Char(string="Material OD")
    tble_finalRX_Material_OS = fields.Char(string="Material OS")
    tble_finalRX_Seg_OD = fields.Char(string="Seg. Ht OD - mm")
    tble_finalRX_Seg_OS = fields.Char(string="Seg. Ht OS - mm")
    tble_finalRX_BC_OD = fields.Char(string="B.C OD - D")
    tble_finalRX_BC_OS = fields.Char(string="B.C OS - D")
    tble_finalRX_TintAR_OD = fields.Char(string="Tint/AR OD")
    tble_finalRX_TintAR_OS = fields.Char(string="Tint/AR OS")

    tble_finalRX_RX_for = fields.Char(string="RX for")
    tble_finalRX_fulltime = fields.Char(string="Full time")
    tble_finalRX_distance = fields.Char(string="Distance")
    tble_finalRX_near = fields.Char(string="Near")
    tble_finalRX_PRN = fields.Char(string="PRN")

    tble_final_eye_defect = fields.Char(string="Eye Defect")

    #Assessments and Plans
    assessments_A1 = fields.Text(string="A1")    
    assessments_P1 = fields.Text(string="P1")
    assessments_A1_date = fields.Date(string="Resolution date")

    #Advice and Recommendation
    advice_patient = fields.Text(string="Advice to Patient")
    recommendation = fields.Text(string="Recommendation")

    #Referral
    referral_notes = fields.Text(string="Referral Notes")
    prescription = fields.Text(string="Prescription")


    @api.multi
    def name_get(self):
        result = []
        for recordcard in self:
            name = recordcard.recordcard_id
            result.append((recordcard.id, name))
        return result

    @api.multi
    @api.depends('patient_id')
    def _compute_branch(self):
        userid = self.env.uid
        user_rec = self.env['res.users'].search([('id', '=', userid)])
        branchid = user_rec.user_branch.id
        for rec in self:
            rec.branch_id = branchid
        return branchid

    @api.onchange('patient_id')
    def _onchange_patient_id(self):
        patientid = self.env.context.get('default_patient_id')        
        #raise ValidationError(_(patient_id))
        if patientid:             
            recordcard_rec = self.env['eye_clinic.record_card'].search([('patient_id', '=', patientid)], order="id desc", limit=1)
            if recordcard_rec:
                last_date = recordcard_rec.date
                self.date_last_eye_exam = datetime.strptime(last_date, '%Y-%m-%d')
                self.where_last_eye_exam = "Med Optics"
            #self.date_last_eye_exam = the_date
            #self.where_last_eye_exam = the_where

    #Put together the RecordCard ID Sequence
    @api.model
    def create(self, vals): 
        #Assign Table for Final RX
        vals['tble_finalRX_OD'] = vals['finalRX_OD']
        vals['tble_finalRX_OS'] = vals['finalRX_OS']
        vals['tble_finalRX_Add_OD'] = vals['finalRX_Add_OD']
        vals['tble_finalRX_Add_OS'] = vals['finalRX_Add_OS']
        vals['tble_finalRX_Type_OD'] = vals['finalRX_Type_OD']
        vals['tble_finalRX_Type_OS'] = vals['finalRX_Type_OS']
        vals['tble_finalRX_PD_OD'] = vals['finalRX_PD_OD']
        vals['tble_finalRX_PD_OS'] = vals['finalRX_PD_OS']
        vals['tble_finalRX_Prism_OD'] = vals['finalRX_Prism_OD']
        vals['tble_finalRX_Prism_OS'] = vals['finalRX_Prism_OS']
        vals['tble_finalRX_Material_OD'] = vals['finalRX_Material_OD']
        vals['tble_finalRX_Material_OS'] = vals['finalRX_Material_OS']
        vals['tble_finalRX_Seg_OD'] = vals['finalRX_Seg_OD']
        vals['tble_finalRX_Seg_OS'] = vals['finalRX_Seg_OS']
        vals['tble_finalRX_BC_OD'] = vals['finalRX_BC_OD']
        vals['tble_finalRX_BC_OS'] = vals['finalRX_BC_OS']
        vals['tble_finalRX_TintAR_OD'] = vals['finalRX_TintAR_OD']
        vals['tble_finalRX_TintAR_OS'] = vals['finalRX_TintAR_OS']

        vals['tble_finalRX_RX_for'] = vals['finalRX_RX_for']
        vals['tble_finalRX_fulltime'] = vals['finalRX_fulltime']
        vals['tble_finalRX_distance'] = vals['finalRX_distance']
        vals['tble_finalRX_near'] = vals['finalRX_near']
        vals['tble_finalRX_PRN'] = vals['finalRX_PRN']

        vals['tble_final_eye_defect'] = vals['final_eye_defect']

        #Get patient_id
        patientid = vals['patient_id']
        #raise ValidationError(_(patientid))
        #Update Appointment Status
        appointment_recordset = self.env['eye_clinic.appointments'].search([('patient_id', '=', patientid)], order="id desc", limit=1)
        appointment_recordset.write({'appointment_status': 'In Progress'})
        #Sequence
        seq= self.env['ir.sequence'].next_by_code('recordcards_sequence')
        vals['recordcard_id'] = seq
        return super(record_card, self).create(vals)


    #Open Sales Order for Record Card
    @api.multi
    def open_sales_order_form(self):
        #Get patient_id
        patientid = self.patient_id.id
        patient_partnerid = self.patient_id.patient_partner_id
        #raise ValidationError(_(patientid))
        #Update Appointment Status
        appointment_recordset = self.env['eye_clinic.appointments'].search([('patient_id', '=', patientid)], order="id desc", limit=1)
        appointment_recordset.write({'appointment_status': 'Done'})
        #Open Sales Order Form 
        view_id = self.env.ref('sale.view_order_form').id
        context ="{'default_recordcard_id':active_id, 'default_patient_id': %d, 'default_partner_id': %d}" % (patientid, patient_partnerid)
        return {
            'name':'sale.order.form',
            'view_type':'form',
            'view_mode':'form',
            #'views' : [(view_id,'form')],
            'res_model':'sale.order',
            'view_id':view_id,
            'type':'ir.actions.act_window',
            #'res_id':self.id,
            'target':'new',
            'context':context,
        }














