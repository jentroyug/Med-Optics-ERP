# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from datetime import datetime
from datetime import timedelta
from odoo.exceptions import Warning as UserError
from odoo.exceptions import ValidationError

#Put together the Time Slots List
slots_list = []
#Start and End time
start_time = '8:00'
end_time = '18:30'
slot_time = 30

time = datetime.strptime(start_time, '%H:%M')
end = datetime.strptime(end_time, '%H:%M')
while time <= end:
	slot_option = (time.strftime("%H:%M"), time.strftime("%H:%M"))
	slots_list.append(slot_option)
	time += timedelta(minutes=slot_time)



class eye_clinic(models.Model):
    _name = 'eye_clinic.eye_clinic'

    name = fields.Char()
    description = fields.Text()


class branches(models.Model):
    _name = 'eye_clinic.branches'
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _order = 'name asc'

    name = fields.Char(string="Branch Name", required=True)
    branch_code = fields.Char(string="Branch Code", required=True)
    phone = fields.Char(string="Phone", required=True)
    email = fields.Char(string="Email")
    address = fields.Text(string="Address", required=True)   
    manager_id = fields.Many2one('res.users', string='Branch Manager', required=True)

    _sql_constraints = [
        ('name_unique',
         'UNIQUE(name)',
         "The Branch name must be unique")
    ]


class appointments(models.Model):
    _name = 'eye_clinic.appointments'
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _order = 'date_appointment desc, patient_id asc'

    appointment_id = fields.Char(string="Appointment No.", readonly=True)
    branch_id = fields.Many2one('eye_clinic.branches', string='Branch', readonly=True, compute="_compute_branch", store=True)
    patient_id = fields.Many2one('eye_clinic.patient', string='Patient', required=True, ondelete='restrict')
    date_appointment = fields.Date(string='Date of Appointment', required=True, default=fields.Date.today) 
    time_slot = fields.Selection(slots_list, string="Time Slot", required=True)
    calendar_timeslot_start = fields.Datetime(string='Date Time Slot - Start', compute="_compute_calendar_timeslot", store=True)
    calendar_timeslot_end = fields.Datetime(string='Date Time Slot - Start', compute="_compute_calendar_timeslot", store=True)  
    urgency_level = fields.Selection([
        ('Normal', "Normal"),
        ('Urgent', "Urgent"),
        ('Medical Emergency', "Medical Emergency"),
    ], string="Urgency Level", required=True)    
    appointment_status = fields.Selection([
        ('Waiting List', "Waiting List"),  
        ('In Progress', "In Progress"),
        ('Done', "Done"),
        ('Cancelled', "Cancelled"),
    ], string="Appointment Status", default='Waiting List', track_visibility='onchange')
    #appointmentline_id = fields.Many2one('eye_clinic.patient', 'All Patients lines')

    _sql_constraints = [
        ('appointment_id_unique',
         'UNIQUE(appointment_id)',
         "The Appointment No. must be unique")
    ]

    _sql_constraints = [
        ('appointment_date_timeslot_unique',
         'UNIQUE(branch_id,date_appointment,time_slot)',
         "The Time Slot for this Date and Branch is already booked!")
    ]
    
    @api.multi
    def name_get(self):
        result = []
        for appt in self:
            name = appt.appointment_id
            result.append((appt.id, name))
        return result

    @api.multi
    @api.depends('date_appointment')
    def _compute_calendar_timeslot(self):
        cal_timeslot = ""
        for rec in self:
        	if(rec.date_appointment and rec.time_slot):
        		cal_timeslot = rec.date_appointment + ' ' + rec.time_slot + ':00'
        		#Convert into datetime 
        		cal_timeslot = datetime.strptime(cal_timeslot, "%Y-%m-%d %H:%M:%S")
        		cal_timeslot = cal_timeslot - timedelta(hours=3)
        		rec.calendar_timeslot_start = cal_timeslot
        		rec.calendar_timeslot_end = cal_timeslot + timedelta(minutes=30)
        return cal_timeslot

    @api.multi
    @api.depends('patient_id')
    def _compute_branch(self):
        userid = self.env.uid
        user_rec = self.env['res.users'].search([('id', '=', userid)])
        branchid = user_rec.user_branch.id
        for rec in self:
            rec.branch_id = branchid
        return branchid

    #Put together the Appointment ID Sequence
    @api.model
    def create(self, vals): 
        seq = self.env['ir.sequence'].next_by_code('appointments_sequence')
        vals['appointment_id'] = seq
        return super(appointments, self).create(vals)


class physician_speciality(models.Model):
    _name = 'eye_clinic.physician_speciality'
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _order = 'name asc'
    
    name = fields.Char(string="Physician Speciality", required=True)
    description = fields.Text(string="Description")

    _sql_constraints = [
        ('name_unique',
         'UNIQUE(name)',
         "The Speciality must be unique")
    ]

class physicians(models.Model):
    _name = 'eye_clinic.physicians'
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _order = 'name asc'
    
    name = fields.Char(string="Physician Name", required=True)
    phone = fields.Char(string="Phone", required=True)
    email = fields.Char(string="Email", required=True)
    address = fields.Text(string="Address", required=True)    
    speciality_id = fields.Many2one('eye_clinic.physician_speciality', string='Speciality', required=True)

    _sql_constraints = [
        ('name_unique',
         'UNIQUE(name)',
         "The Physician name must be unique")
    ]


class insurance_companies(models.Model):
    _name = 'eye_clinic.insurance_companies'
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _order = 'name asc'

    name = fields.Char(string="Company Name", required=True)
    phone = fields.Char(string="Phone", required=True)
    email = fields.Char(string="Email", required=True)
    address = fields.Text(string="Address", required=True)
    contactperson_name = fields.Char(string="Contact Person Name", required=True)
    contactperson_phone = fields.Char(string="Contact Person Phone", required=True)
    contactperson_email = fields.Char(string="Contact Person Email", required=True)
    contract_date_start = fields.Date(string='Start Date of Contract', required=True) 
    contract_date_end = fields.Date(string='End Date of Contract', required=True) 
    current_contract = fields.Binary(string='Current Contract')
    contract_file_name = fields.Char(string="Contract File Name")


    _sql_constraints = [
        ('name_unique',
         'UNIQUE(name)',
         "The Insurance Company name must be unique")
    ]


class insurance_policies(models.Model):
    _name = 'eye_clinic.insurance_policies'
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _order = 'name asc'
    
    name = fields.Char(string="Policy Title", required=True)
    policy_code = fields.Char(string="Policy Code", required=True)
    insurance_type = fields.Selection([
        ('Private', "Private"),
        ('Government', "Government"),
        ('Organisation/Institution', "Organisation/Institution"),
        ('Labour Union', "Labour Union"),
    ], string="Insurance Type")   
    extra_info = fields.Text(string="Extra Information")    

    _sql_constraints = [
        ('name_unique',
         'UNIQUE(name)',
         "The Policy name must be unique")
    ]

    _sql_constraints = [
        ('policy_code_unique',
         'UNIQUE(policy_code)',
         "The Policy Code must be unique")
    ]

class outreach_regions(models.Model):
    _name = 'eye_clinic.outreach_regions'
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _order = 'name asc'

    sales_team_id = fields.Many2one('crm.team', string='Sales Team', required=True)
    name = fields.Char(string="Outreach Region", required=True)
    description = fields.Text(string="Description")

    _sql_constraints = [
        ('name_unique',
         'UNIQUE(name)',
         "The Outreach Region name must be unique")
    ]


class outreach_locations(models.Model):
    _name = 'eye_clinic.outreach_locations'
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _order = 'name asc'
    
    name = fields.Char(string="Outreach Locations", required=True)
    outreach_region_id = fields.Many2one('eye_clinic.outreach_regions', string='Outreach Region', required=True)
    description = fields.Text(string="Description") 

    _sql_constraints = [
        ('name_unique',
         'UNIQUE(name)',
         "The Outreach Location name must be unique")
    ]

    @api.multi
    def name_get(self):
        result = []
        for rec in self:
            outreachregion_id = rec.outreach_region_id.id            
            outreach_region_record = self.env['eye_clinic.outreach_regions'].search([('id', '=', outreachregion_id)])
            #raise ValidationError(_(outreach_region_record.name))
            outreachregion_name = outreach_region_record.name
            name = rec.name + ' / ' + outreachregion_name
            result.append((rec.id, name))
        return result