# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from datetime import datetime
from datetime import date
from dateutil.relativedelta import relativedelta
from odoo.exceptions import Warning as UserError
import re
from odoo.exceptions import ValidationError
from lxml import etree


class patient(models.Model):
    _name = 'eye_clinic.patient'
    _inherit = ['mail.thread', 'ir.needaction_mixin']
    _description = 'Eye Clinic Patients'
    _order = 'patient_id'

    name = fields.Char(string="Patient Name", compute="_compute_name", store=True)
    surname = fields.Char(string="Surname", required=True)
    first_name = fields.Char(string="First Name", required=True)
    given_name = fields.Char(string="Given/Middle Name")
    title = fields.Selection([
        ('Mr.', "Mr."),
        ('Mrs.', "Mrs."),
        ('Miss', "Miss"),
        ('Ms.', "Ms."),
        ('Dr.', "Dr."),
        ('Prof.', "Prof."),
        ('Master', "Master"),
        ('Hon.', "Hon."),
        ('Owek.', "Owek."),
        ('His Grace.', "His Grace."),
        ('HH.', "HH."),
        ('HE.', "HE."),
    ], string="Title", required=True)    
    patient_id = fields.Char(string="Patient No.", readonly=True)
    phone = fields.Char(string="Mobile Tel No.", required=True)
    phone2 = fields.Char(string="Other Tel No.")    
    email = fields.Char(string="Email")
    address = fields.Text(string="Address", required=True)
    dob = fields.Date(string='Date of Birth', required=True)
    age = fields.Integer(string="Patient Age (years)", compute="_compute_age", readonly=True, store=True)
    sex = fields.Selection([
        ('Male', "Male"),
        ('Female', "Female"),
    ], string="Sex", required=True)  
    patient_do_following = fields.Selection([
        ('Driver', "Driver"),
        ('Sports', "Sports"),
        ('VDU', "VDU"),
        ('None', "None"),
    ], string="Does the patient do any of the following?", required=True) 
    occupation = fields.Char(string="Occupation", required=True)
    hobbies = fields.Char(string="Hobbies")
    hear_aboutus = fields.Selection([
        ('News Paper', "News Paper"),
        ('TV', "TV"),
        ('Radio', "Radio"),
        ('Magazine', "Magazine"),
        ('Internet Search', "Internet Search"),
        ('Facebook', "Facebook"),
        ('Twitter', "Twitter"),
        ('Instagram', "Instagram"),
        ('LinkedIn', "LinkedIn"),
        ('Youtube', "Youtube"),
        ('Google Ads', "Google Ads"),
        ('Outreach', "Outreach"),        
        ('Referral', "Referral"),
        ('Friend', "Friend"),
        ('Other', "Other"),
    ], string="How did you hear about us?")  
    hear_aboutus_other = fields.Char(string="How did you hear about us? Other Specify")
    hear_aboutus_outreach = fields.Many2one('eye_clinic.outreach_locations', string='Outreach', required=True)
    optin_messages = fields.Boolean(string="Opt-In to Receive Promotional Messages", default=True)
    patient_profile = fields.Binary(string='Patient Profile')
    profile_file_name = fields.Char(string="Profile File Name")
    patient_partner_id = fields.Many2one('res.partner', string='Customer', required=True)
    last_visitdate = fields.Date(string='Last Date - Patient Visit ', compute="_compute_last_visitdate", store=True)
    appointment_lines = fields.One2many('eye_clinic.appointments', 'patient_id', string='Appointments') 
    recordcard_lines = fields.One2many('eye_clinic.record_card', 'patient_id', string='Record Cards')

    created_by = fields.Many2one('res.users', 
        string='Created by User',  store=True, readonly=True, default=lambda self: self.env.uid) 
    createdby_branch = fields.Many2one('eye_clinic.branches', 
        string='Created at Branch', readonly=True, compute="_compute_createdby_branch", store=True) 


    _sql_constraints = [
        ('patient_id_unique',
         'UNIQUE(patient_id)',
         "The Patient No. must be unique")
    ]

    _sql_constraints = [
        ('patient_name_dob_unique',
         'UNIQUE(name,dob)',
         "The Patient Name and Date of Birth must be unique")
    ]

    @api.one
    @api.constrains('age')
    def _check_age(self):
        #Check for entry
        if(self.age < 0 or self.age > 120):
            raise ValidationError(_('''Age must be between 0 and 120'''))

    @api.multi
    @api.constrains('phone')
    def _check_phone(self):
        for rec in self:
            if rec.phone and len(rec.phone) != 10:
                raise ValidationError(_("Enter valid 10 digits Mobile number"))
            elif rec.phone and re.match("^[0-9]{10}$", rec.phone) == None:
                raise ValidationError(_("Enter valid 10 digits for Mobile Tel. No"))

    @api.onchange('phone2')
    def _onchange_phone2(self):
        if self.phone2 and len(self.phone2) != 10:
            raise ValidationError(_("Enter valid 10 digits Mobile number"))
        elif self.phone2 and re.match("^[0-9]{10}$", self.phone2) == None:
            raise ValidationError(_("Enter valid 10 digits for Other Mobile Tel. No"))

    @api.multi
    @api.constrains('email')
    def _validate_email(self):
       if self.email:
        match = re.match('^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$', self.email)
        if match == None:
            raise ValidationError(_("Enter valid Email"))

    @api.multi
    def name_get(self):
        result = []
        for patient in self:
            name = patient.name + ' - ' + patient.phone + ' - ' + patient.dob
            result.append((patient.id, name))
        return result

    @api.onchange('dob')
    def _onchange_dob(self):
    	for rec in self:
    		if rec.dob:
    			dt = rec.dob
    			d1 = datetime.strptime(dt, "%Y-%m-%d").date()
    			d2 = date.today()
    			rd = relativedelta(d2, d1)
    			rec.age = rd.years  #str(rd.years) + ' years

    @api.multi
    @api.depends('dob')
    def _compute_age(self):
    	the_age = 0
    	for rec in self:
    		if rec.dob:
    			dt = rec.dob
    			d1 = datetime.strptime(dt, "%Y-%m-%d").date()
    			d2 = date.today()
    			rd = relativedelta(d2, d1)
    			the_age = rd.years  #str(rd.years) + ' years' 
    		rec.age = the_age
    	return the_age

    @api.multi
    @api.depends('surname','first_name','given_name')
    def _compute_name(self):
        the_name = ''
        for rec in self:
            if rec.surname and rec.first_name:
                if rec.given_name:
                    the_name = rec.surname + ' ' + rec.first_name + ' ' + rec.given_name
                else:
                    the_name = rec.surname + ' ' + rec.first_name
            rec.name = the_name
        return the_name

    @api.multi
    @api.depends('recordcard_lines')
    def _compute_last_visitdate(self):
        the_date = ''
        for rec in self:
            if len(rec.recordcard_lines) > 0:
                patientid = rec.patient_id
                #Get last visit date by patient
                recordcard_rec = self.env['eye_clinic.record_card'].search([('patient_id', '=', patientid)], order="id desc", limit=1)
                the_date = recordcard_rec.date 
            rec.last_visitdate = the_date
        return the_date

    @api.multi
    @api.depends('created_by')
    def _compute_createdby_branch(self):
        the_branch = 0
        for rec in self:
            if rec.created_by:
                userid = rec.created_by.id
                user_rec = self.env['res.users'].search([('id', '=', userid)])
                user_branchid = user_rec.user_branch.id
                the_branch = user_branchid
            rec.createdby_branch = the_branch
        return the_branch

    
    #Create Customer Record
    def _create_customer_record(self,name,phone,mobile,email,street):
        #Get  Customer Receiable and Payable Accounts
        receivable_acct = self.env['account.account'].search([('name', '=', 'Sales Acccount')], limit=1)
        receivable_acct_id = receivable_acct.id
        payable_acct = self.env['account.account'].search([('name', '=', 'Returns Account')], limit=1)
        payable_acct_id = payable_acct.id
        #Create Patient as res.partner record and get id
        #Insert Query Database
        self._cr.execute("""INSERT INTO res_partner 
                            (name, phone, mobile, email, street, active, display_name, supplier, is_company, employee, customer, type,
                            partner_share, notify_email, opt_out, picking_warn, invoice_warn, sale_warn, purchase_warn, company_id, 
                            color, lang) 
                            VALUES ('%s','%s', '%s', '%s', '%s', '1', '%s', '0', '0', '0', '1', '%s', '1', '%s', '0', '%s', '%s', '%s', 
                                '%s', '%d', '%d', '%s')"""  
                            % (name, phone, mobile, email, street, name, 'contact','always', 'no-message', 'no-message', 'no-message', 
                                'no-message', 1, 0, 'en_US'))        
        #raise ValidationError(_(partner_record)) 
        #Get Partnerid inserted into table
        partner_record = self.env['res.partner'].search([('name', '=', name)], limit=1)    
        partnerid = partner_record.id  
        partner_record.write({'commercial_partner_id': partnerid})
        return partnerid
        

    #Put together the Patient ID Sequence - res.partner
    @api.model
    def create(self, vals):
        #Sequence + Branch
        userid = self.env.uid
        user_rec = self.env['res.users'].search([('id', '=', userid)])
        branchid = user_rec.user_branch.id
        branch_rec = self.env['eye_clinic.branches'].search([('id', '=', branchid)])    
        branchcode = branch_rec.branch_code

        seq = self.env['ir.sequence'].next_by_code('patient_sequence')
        seq_list = seq.split('-')
        seq_branch = str(seq_list[0]) + '-' + str(branchcode) + '-' + str(seq_list[1])

        #Create Customer values
        if vals.get('given_name'):
            thename = vals['surname'] + ' ' + vals['first_name'] + ' ' + vals['given_name']
        else:
            thename = vals['surname'] + ' ' + vals['first_name']        
        name = thename + ' (' + seq_branch + ')'
        phone = vals['phone']
        mobile = vals['phone2']
        email = vals['email']
        street = vals['address']
        partnerid = self._create_customer_record(name,phone,mobile,email,street)
        vals['patient_partner_id'] = partnerid        
        vals['patient_id'] = seq_branch
        return super(patient, self).create(vals)


    #Override - Add Search/Filter Options
    @api.model
    def fields_view_get(self, view_id=None, view_type=False, toolbar=False, submenu=False):
        #Get filter Options
        branches_recordset = self.env['eye_clinic.branches'].search([])
        res = super(patient, self).fields_view_get(view_id, view_type, toolbar=toolbar, submenu=submenu)
        doc = etree.XML(res['arch'])
        if view_type == 'tree':
            # for node in doc.xpath("//filter[@name='createdby_branch_filter']"):
            #     for branch in branches_recordset:
            #         user_filter =  "[('createdby_branch', '='," + str(branch.name) + " )]"
            #         node.set('domain',user_filter)
            # res['arch'] = etree.tostring(doc)

            for node in doc.xpath("//search[@name='search_filter_top']"):
                for branch in branches_recordset:
                    branch_name = str(branch.name)
                    filter_domain =  "[('createdby_branch', '='," + str(branch.name) + " )]"
                    the_filter = '<filter string="' + branch_name + '" domain="' + filter_domain + '"/>'
                    node.set('filter', the_filter)
            res['arch'] = etree.tostring(doc)
        return res












