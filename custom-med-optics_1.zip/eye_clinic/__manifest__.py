# -*- coding: utf-8 -*-
{
    'name': "Eye Clinic Module",

    'summary': """
        Med-Optics Eye Clinic Module""",

    'description': """
        This Module handles functionality related to the Eye Clinic for Med Optics
    """,

    'author': "Jentroy",
    'website': "http://www.jentroy.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/10.0/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Eye-Clinic',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','sale','account'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/patients_view.xml',
        'views/recordcard_view.xml',
        'views/templates.xml',
    ],
    'css': [
        #Other Styles
        'static/src/less/styles.css'
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],

    # whether Module is installable
    'installable': True,
    'auto-install': False,
}