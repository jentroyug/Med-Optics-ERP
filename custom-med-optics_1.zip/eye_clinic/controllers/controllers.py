# -*- coding: utf-8 -*-
from odoo import http

# class EyeClinic(http.Controller):
#     @http.route('/eye_clinic/eye_clinic/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/eye_clinic/eye_clinic/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('eye_clinic.listing', {
#             'root': '/eye_clinic/eye_clinic',
#             'objects': http.request.env['eye_clinic.eye_clinic'].search([]),
#         })

#     @http.route('/eye_clinic/eye_clinic/objects/<model("eye_clinic.eye_clinic"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('eye_clinic.object', {
#             'object': obj
#         })