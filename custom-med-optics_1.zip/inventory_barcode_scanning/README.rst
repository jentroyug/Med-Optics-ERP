Barcode scanning in inventory v10
=================================

This module will used for barcode scanning in inventory.
Depends
=======
[stock] addon Odoo

Tech
====
* [Python] - Models
* [XML] - Odoo views

Installation
============
- www.odoo.com/documentation/10.0/setup/install.html
- Install our custom addon

License
=======
GNU LESSER GENERAL PUBLIC LICENSE, Version 3 (LGPLv3)
(http://www.gnu.org/licenses/agpl.html)

Credits
=======
Cybrosys Techno Solutions

Authors
-------
* Sreejith P <https://www.cybrosys.com>
* Aswani PC <https://www.cybrosys.com>
