# -*- coding: utf-8 -*-

{
    'name': 'Fabric Mail Backend Theme',
    'summary': 'Odoo 10 Fabric Mail Backend Theme',
    'category': 'Themes/Miscellaneous',
    'version': '10.0.0.1',
    'author': 'Young Tailor',
    'live_test_url': 'http://45.77.38.140:8069',
    'description':
        """
Fabric Email Theme
===========================
This is the theme for Discuss module and it should be installed with https://apps.odoo.com/apps/themes/10.0/theme_fabric/ to have the best look.
        """,
    'depends': ['mail'],
    'data': [
        'views/assets.xml',
    ],
    'images': [
        'static/description/fabric_email_screenshot.png',
        'static/description/thumb.png',
    ],
    'support': 'kyehani@icloud.com',
    'license': 'LGPL-3',
    'currency': 'EUR',
}
